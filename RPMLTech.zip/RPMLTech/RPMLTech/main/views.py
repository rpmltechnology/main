from django.shortcuts import render, HttpResponse

# Create your views here.
def index(request):
    return render(request, 'templates/index.html')

def about_us(request):
    return render(request, 'templates/About-us.html')

def our_team(request):
    return render(request, 'templates/our-team.html')

def django(request):
    return render(request, 'templates/django.html')

def automation_selenium(request):
    return render(request, 'templates/automation-selenium.html')

def blog(request):
    return render(request, 'templates/blog.html')

def business_solution(request):
    return render(request, 'templates/business-solution.html')

def contact_us(request):
    return render(request, 'templates/contact-us.html')

def data_analytics(request):
    return render(request, 'templates/data-analytics.html')

def django_development(request):
    return render(request, 'templates/django_development.html')

def flask(request):
    return render(request, 'templates/flask.html')

def industries(request):
    return render(request, 'templates/industries.html')

def machine_learning(request):
    return render(request, 'templates/machine-learning.html')

def python(request):
    return render(request, 'templates/python.html')

def r_language_programming(request):
    return render(request, 'templates/r-language-programming.html')

def selenium(request):
    return render(request, 'templates/selenium.html')

def tableau_for_visualization(request):
    return render(request, 'templates/tableau-for-visualization.html')

def technology(request):
    return render(request, 'templates/technology.html')
