from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name= "index"),
    path('about_us/', views.about_us, name="about_us"),
    path('automation_selenium/', views.automation_selenium, name="automation_selenium"),
    path('blog/', views.blog, name="blog"),
    path('business_solution/', views.business_solution, name="business_solution"),
    path('contact_us/', views.contact_us, name="contact_us"),
    path('data_analytics/', views.data_analytics, name="data_analytics"),
    path('django/', views.django, name="django"),
    path('django_development/', views.django_development, name="django_development"),
    path('flask/', views.flask, name="flask"),
    path('industries/', views.industries, name="industries"),
    path('machine_learning/', views.machine_learning, name="machine_learning"),
    path('our_team/', views.our_team, name="our_team"),
    path('python/', views.python, name="python"),
    path('r_language_programming/', views.r_language_programming, name="r_programming_language"),
    path('selenium/', views.selenium, name="selenium"),
    path('tableau_for_visualization/', views.tableau_for_visualization, name="tableau_for_visualization"),
    path('technology/', views.technology, name="technology"),

]